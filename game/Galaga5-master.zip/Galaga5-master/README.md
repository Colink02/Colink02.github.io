# Galaga5

[The last commit I'll make to this repo for a while*](http://hoorayimhelping.github.com/Galaga5/)

This is a ~~clone~~ interpretation of the arcade classic Galaga done in HTML5. The game engine and logic is written in JavaScript and rendered using HTML5's cavans tag and a 2d rendering context. All handwritten by me cause why not.

Arrow keys move left and right

Spacebar fires

Escape pauses

## About

I'm writing this because I've always wanted to make a video game, and I figured I'd start with a clone. I chose Galaga because my ex really enjoyed it as a kid and it seemed like a good way to impress her. Spoiler alert: it didn't.

I was working on this on the subway one day and the lady sitting next to me started talking to me about the game. She said it's so cool cause she remembered playing this game in the arcade as a kid and that I should definitely make it work on phones and tablets and if I did, she would play it. It was the best interaction I've ever had with a stranger in New York City.

*Design decisions I made three years ago are making it difficult to go on. I learned a lot with this project, what I needed to.
